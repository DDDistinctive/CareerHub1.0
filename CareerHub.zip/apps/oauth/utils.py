from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from django.conf import settings
def check_access_token(openid):
    '''
    解密
    :param openid:
    :return: openid 明文
    '''
    serializer=Serializer(settings.SECRET_KEY,60)
    try:
        data=serializer.loads(openid)
    except Exception as e:
        return None
    else:
        return data.get('openid')

def generate_access_token(openid):
    '''
    序列化opeanid
    :param openid: 明文
    :return: 密文
    '''
    serializer=Serializer(settings.SECRET_KEY,600)
    data={'openid':openid}
    token=serializer.dumps(data)
    return token.decode()

















