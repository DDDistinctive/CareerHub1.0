
from django.urls import path,re_path
from apps.oauth import views
app_name='oauth'
urlpatterns = [
    path('qq/login/',views.QQAuthURLView.as_view()),
    path('oauth_callback/',views.QQAuthUserView.as_view())
]
