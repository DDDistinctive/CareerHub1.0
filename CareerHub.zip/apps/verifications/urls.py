

from django.urls import path,re_path
from apps.verifications import views
urlpatterns = [
    re_path(r'^image_codes/(?P<uuid>[\w-]+)/$',views.ImageCodeView.as_view()),
    re_path('^email_codes/(?P<email>([A-Za-z0-9]+[.-_])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+)/$',views.emailCodeView.as_view())

]
