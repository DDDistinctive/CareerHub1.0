CLIENT_ID_CV="g9a6du7qU3P1qhQ6jvGlp9oG"
CLIENT_SECRET_CV="9zEKOd4WjvG5Op3OGXpDHTXnK0zvys3g"
#爬取数据保存时间10分钟
SCRAPYDATA_AGE=600
#简历分析保存时间
CVANALYZE_AGE=600
#openai key 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
# OPENAI_KEY = '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'
OPENAI_KEY = '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'
GET_ACCESS_KEY_URL="https://aip.baidubce.com/oauth/2.0/token"
# "?grant_type=client_credentials&client_id=&client_secret=XOzxN879LFbHdKXXTHVd4vzYSz6VrBbL"
CLIENT_ID="kukQvg9pX6VHeI0fciCdZQAc"
CLIENT_SECRET="XOzxN879LFbHdKXXTHVd4vzYSz6VrBbL"
#acess_key 的保存时间
ACCESS_KEY_AGE=3600*24*28
class SCRAPYCODE:
    OK = "0"
    THROTTLINGERR="401"
    PRIVACYCLOSE='402'
    NOTFINDUSER='403'

err_msg = {
    SCRAPYCODE.OK: "成功",
    SCRAPYCODE.THROTTLINGERR:'访问过于频繁',
    SCRAPYCODE.PRIVACYCLOSE:'用户隐私未公开',
    SCRAPYCODE.NOTFINDUSER:'没有找到该用户的信息'
    }
