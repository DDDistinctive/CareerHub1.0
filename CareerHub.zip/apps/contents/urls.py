
from django.urls import path,re_path
from apps.contents import views
app_name='contents'
urlpatterns = [
    #首页首页
    path('',views.IndexView.as_view(),name='index'),
    #职业画像页面
    path('careerhub/',views.CareerView.as_view(),name='careerhub'),
    #爬取web信息
    re_path('getinfo/',views.ScrapyView.as_view(),name='getinfo'),
    #简历分析
    re_path('cvanalyze/',views.CvAnalyzeView.as_view(),name='cvanalyze'),
    #web行为分析
    path('web_action/',views.ActionAnalyzeView.as_view(),name="web_action")


]
