from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.views import View
from django import http
from utils.response_code import RETCODE
from django_redis import get_redis_connection
from apps.contents.constants import SCRAPYCODE, err_msg, SCRAPYDATA_AGE, CVANALYZE_AGE
from apps.contents.utils import SCRAPY_DIR, cv_analyze, web_action_analyze


class IndexView(View):
    def get(self, request):
        '''
        提供首页
        :param request:
        :return: 首页
        '''
        return render(request, 'index.html')


class CareerView(View):
    def get(self, request):
        '''
        提供职业画像页面
        :param request:
        :return: 职业画像页面
        '''
        return render(request, 'home.html')


class ScrapyView(LoginRequiredMixin, View):
    login_url = '/users/login/'

    def get(self, request):
        '''
        爬虫逻辑
        :param request:
        :return: JSON
        '''
        # 获取爬取的web名
        scrapyweb = request.GET.get('scrapyweb')
        # 获取kwy1
        keyword = request.GET.get('key1')
        # username = request.user.username
        username = request.user.username
        return SCRAPY_DIR[scrapyweb](keyword, username)
        # username=request.user.username
        # if scrapyweb=='bilibili':
        #     # 获取前端发送的数据
        #     key1 = request.GET.get('key1')
        #     bilibili = Bilibili()
        #     bilibili.getSession()
        #     mid = bilibili.searchUserUid(key1)
        #     if mid == -1:
        #         return http.JsonResponse('没有改用户的信息')
        #     text = bilibili.unameInfo(mid)
        #     request.session['bilibili'] = text
        #     if text == "":
        #         return http.JsonResponse({'code':SCRAPYCODE.PRIVACYCLOSE,
        #                                   'errmsg':err_msg.get(SCRAPYCODE.PRIVACYCLOSE)})
        #     redis_conn=get_redis_connection('scrapy_data')
        #     redis_conn.setex('bilibili_%s'%username,SCRAPYDATA_AGE,text)
        #     return http.JsonResponse({'code':SCRAPYCODE.OK,'errmsg':err_msg.get(SCRAPYCODE.OK)})
        # elif scrapyweb=='csdn':
        #     # 获取前端发送的数据
        #     key1 = request.GET.get('key1')
        #     csdn = Csdn()
        #     mid = csdn.searchUserInfo(key1)
        #     if mid == -1:
        #         return http.JsonResponse({'code':SCRAPYCODE.NOTFINDUSER,
        #                                   'errmsg':err_msg.get(SCRAPYCODE.NOTFINDUSER)})
        #
        #     text = csdn.Midinfo(mid)
        #     request.session['csdn'] = text
        #     redis_conn = get_redis_connection('scrapy_data')
        #     redis_conn.setex('csdn_%s' % username, SCRAPYDATA_AGE, text)
        #     return http.JsonResponse({'code':SCRAPYCODE.OK,'errmsg':err_msg.get(SCRAPYCODE.OK)})
        # elif scrapyweb=='github':
        #     # 获取前端发送的数据
        #     key1 = request.GET.get('key1')
        #     github = Github()
        #     text = github.unameinfo(key1)
        #     request.session['github'] = text
        #     redis_conn = get_redis_connection('scrapy_data')
        #     redis_conn.setex('github_%s' % username, SCRAPYDATA_AGE, text)
        #     return http.JsonResponse({'code':SCRAPYCODE.OK,'errmsg':err_msg.get(SCRAPYCODE.OK)})
        # elif scrapyweb=='jbook':
        #     # 获取前端发送的数据
        #     key1 = request.GET.get('key1')
        #     jbook = Jbook()
        #     text = jbook.Midinfo(key1)
        #     request.session['jbook'] = text
        #     redis_conn = get_redis_connection('scrapy_data')
        #     redis_conn.setex('jbook_%s' % username, SCRAPYDATA_AGE, text)
        #     return http.JsonResponse({'code':SCRAPYCODE.OK,'errmsg':err_msg.get(SCRAPYCODE.OK)})
        # elif scrapyweb=='weibo':
        #     # 获取前端发送的数据
        #     key1 = request.GET.get('key1')
        #     weibo = Weibo()
        #     text = weibo.Midinfo(key1)
        #     request.session['weibo'] = text
        #     redis_conn = get_redis_connection('scrapy_data')
        #     redis_conn.setex('weibo_%s' % username, SCRAPYDATA_AGE, text)
        #     return http.JsonResponse({'code':SCRAPYCODE.OK,'errmsg':err_msg.get(SCRAPYCODE.OK)})
        # elif scrapyweb=='zhihu':
        #     # 获取前端发送的数据
        #     key1 = request.GET.get('key1')
        #     zhihu = Zhihu()
        #     text = zhihu.Midinfo(key1)
        #     request.session['zhihu'] = text
        #     redis_conn = get_redis_connection('scrapy_data')
        #     redis_conn.setex('zhihu_%s' % username, SCRAPYDATA_AGE, text)
        #     return http.JsonResponse({'code':SCRAPYCODE.OK,'errmsg':err_msg.get(SCRAPYCODE.OK)})
        # elif scrapyweb=='leetcode':
        #     # 获取前端发送的数据
        #     key1 = request.GET.get('key1')
        #     leetcode = Leetcode()
        #     zhihu = Zhihu()
        #     text = zhihu.Midinfo(key1)
        #     request.session['leetcode'] = text
        #     redis_conn = get_redis_connection('scrapy_data')
        #     redis_conn.setex('lsstcode_%s' % username, SCRAPYDATA_AGE, text)
        #     return http.JsonResponse({'code': SCRAPYCODE.OK, 'errmsg': err_msg.get(SCRAPYCODE.OK)})
        #     # 处理其他请求方法或非AJAX请求
        #     # 获取前端发送的数据
        # elif scrapyweb=='cloudmusic':
        #     key1 = request.GET.get('key1')
        #     cloudmusic = Cloudmusic()
        #     text = cloudmusic.Midinfo(key1)
        #     request.session['cloudmusic'] = text
        #     redis_conn = get_redis_connection('scrapy_data')
        #     redis_conn.setex('cloudmusic_%s' % username, SCRAPYDATA_AGE, text)
        #     return http.JsonResponse({'code': SCRAPYCODE.OK, 'errmsg': err_msg.get(SCRAPYCODE.OK)})
        # elif scrapyweb=='douban':
        #     # 获取前端发送的数据
        #     print(1)
        #     key1 = request.GET.get('key1')
        #     douban = Douban()
        #     text1 = douban.movieinfo(key1)
        #     text2 = douban.bookinfo(key1)
        #     request.session['movie'] = text1
        #     request.session['book'] = text2
        #
        #     redis_conn = get_redis_connection('scrapy_data')
        #     redis_conn.setex('douban_movie_%s' % username, SCRAPYDATA_AGE, text1)
        #     redis_conn.setex('douban_book_%s' % username, SCRAPYDATA_AGE, text2)
        #     return http.JsonResponse({'code': SCRAPYCODE.OK, 'errmsg': err_msg.get(SCRAPYCODE.OK)})


#class CvAnalyzeView(LoginRequiredMixin, View):
 #   login_url = '/users/login/'

  #  def post(self, request):

   #     file = request.FILES.get('pdffile')
    #    if file is None:
       #     return http.HttpResponseForbidden('缺少必传参数')
     #   username = request.user.username
      #  cv_result = cv_analyze(file)
        # redis_conn = get_redis_connection('analyze_data')
        # redis_conn.setex('cv_%s' % username, CVANALYZE_AGE, cv_result)
        # return http.JsonResponse({'code': RETCODE.OK, 'errmsg': '成功', 'data': cv_result})


       # result_dict = web_action_analyze(username)
       # result_dict['cv'] = cv_result
       # print("*" * 30)
       # print(result_dict)
        # redis_conn = get_redis_connection('analyze_data')
        # result_dict['cv'] = redis_conn.get('cv_%s' % username)

        # if result_dict['cv'] is None:
        #     result_dict['cv'] = -1
        # else:
        #     result_dict['cv'] = result_dict['cv'].decode()
       # return render(request, 'paper.html', result_dict)

from apps.users.models import UserInfo
class CvAnalyzeView(LoginRequiredMixin, View):
    login_url = '/users/login/'

    def post(self, request):

        file = request.FILES.get('pdffile')
        if file is None:
            cv_result="未上传简历"
        else:
            cv_result = cv_analyze(file)
        username = request.user.username

        result_dict = web_action_analyze(username)
        result_dict['cv'] = cv_result
       # print('-'*35)
        user=request.user
        userinfo,_= UserInfo.objects.get_or_create(user=user)
        userinfo.result=f"{result_dict}"
        userinfo.save()
        print("all clear")
        return render(request, 'paper.html', result_dict)

class ActionAnalyzeView(View):
    login_url = '/users/login/'
    def post(self, request):
        print("简历sdfffsss\n\n\n")
        username = request.user.username
        result_dict = web_action_analyze(username)
        redis_conn = get_redis_connection('analyze_data')
        result_dict['cv'] = redis_conn.get('cv_%s' % username)
        if result_dict['cv'] is None:
            result_dict['cv']=-1
        else:
            result_dict['cv']=result_dict['cv'].decode()
        user=request.user
        userinfo,_= UserInfo.objects.get_or_create(user=user)
        userinfo.result=f"{result_dict}"
        userinfo.save()
        return render(request, 'paper.html', result_dict)
