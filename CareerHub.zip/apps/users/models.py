from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.
class User(AbstractUser):
    class Meta:
        db_table='tb_users'
        verbose_name='用户'
        verbose_name_plural=verbose_name
class UserInfo(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile',unique=True)
    sid = models.CharField(max_length=20, null=True, verbose_name='学号')
    name = models.CharField(verbose_name='姓名', max_length=10, null=True)
    age = models.IntegerField(verbose_name='年龄', null=True)
    gender = models.CharField(max_length=1, choices=[(0, '男'), (1, '女')], null=True, verbose_name='性别')
    wx = models.CharField(max_length=30, verbose_name='微信', null=True)
    phone = models.CharField(max_length=20, null=True, verbose_name='电话')
    school = models.CharField(max_length=20, null=True, verbose_name='学校')
    faculty = models.CharField(max_length=20, null=True, verbose_name='院系')
    major = models.CharField(max_length=20, null=True, verbose_name='专业')
    result=models.TextField(max_length=1000)
    grade = models.CharField(max_length=10, null=True, verbose_name='年级')
    class Meta:
        db_table='tb_userinfo'
