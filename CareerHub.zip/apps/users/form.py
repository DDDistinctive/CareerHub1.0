from django import forms

class RegisterForm(forms.Form):
    username=forms.CharField(max_length=20,min_length=5,required=True,error_messages={
        'max_length':'用户名最大为20位',
        'min_length':'用户名最短为5位'
    })
    password = forms.CharField(max_length=20, min_length=8, required=True)
    email=forms.EmailField()

class LoginForm(forms.Form):
    username = forms.CharField(max_length=20, min_length=5, required=True)
    password = forms.CharField(max_length=20, min_length=8, required=True,error_messages={
        'max_length':'密码最大为20位',
        'min_length':'密码最短为5位'
    })
    remembered=forms.BooleanField(required=False)
class ResetPwdForm(forms.Form):
    email = forms.EmailField(required=True)
    password = forms.CharField(max_length=20, min_length=8, required=True)
    email_code=forms.CharField(min_length=3,max_length=10,required=True)


class UserInfoForm(forms.Form):
    name=forms.CharField(required=False)
    age=forms.IntegerField(required=False)
    gender=forms.CharField(required=False)
    email=forms.CharField(required=False)
    wx=forms.CharField(required=False)
    school=forms.CharField(required=False)
    faculty=forms.CharField(required=False)
    major=forms.CharField(required=False)
    grade=forms.CharField(required=False)
    sid=forms.CharField(required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for field_name in self.fields:
            self.fields[field_name].strip = True

    def clean(self):
        cleaned_data = super().clean()

        for field_name in self.fields:
            value = cleaned_data.get(field_name)
            if isinstance(value, str) and value.strip() == '':
                cleaned_data[field_name] = None

        return cleaned_data
