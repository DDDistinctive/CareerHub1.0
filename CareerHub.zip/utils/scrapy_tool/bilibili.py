import requests
import json
import urllib.parse
import re
'''
import urllib.parse

params = {'key1': 'value1', 'key2': '中文'}
encoded_params = urllib.parse.urlencode(params)
print(encoded_params)
'''
class Bilibili:
    def __init__(self):
        self.headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36',
        }
        self.url='https://www.bilibili.com/'
    def getSession(self):
        self.session=requests.session()
        resp=self.session.get(url=self.url,headers=self.headers)
        self.cookie=self.session.cookies.items()

    def searchUserUid(self,user):
        params={
        'category_id':'',
        'search_type':'bili_user',
        'ad_resource':'5646',
        '__refresh__':'true',
        '_extra':'',
        'context':'',
        'page': '1',
        'page_size': '36',
        'order': '',
        'duration': '',
        'from_source': '',
        'from_spmid': '333.337',
        'platform': 'pc',
        'highlight': '1',
        'single_column': '0',
        'keyword': user,
        'qv_id': 'P6KOmkUDHLkq8yWBpqI720hVB5MTVIFf',
        'source_tag': '3',
        'gaia_vtoken': '',
        'order_sort': '0',
        'user_type': '0',
        'dynamic_offset': '0',
        'web_location': '1430654',
        'w_rid': '0c4fd44501e0d77f23564b3c9f6e5bf2',
        'wts': '1697543148'

        }
        encoded_params = urllib.parse.urlencode(params)
        resp=self.session.get(url='https://api.bilibili.com/x/web-interface/wbi/search/type?'+encoded_params,
                           headers=self.headers)
        # print(resp.text)
        json_data=json.loads(resp.text)
       # print(json_data)
        try:
            result=json_data['data']['result']
        except:
            return -1

        for i in result:
            if i['uname']==user:
                return i['mid']
        return -1
            # print('uname:',i['uname'],'mid:',i['mid'],'fans:',i['fans'])


    def unameInfo(self,vmid):
        #72844520
        params={
            "type": 1,
            "follow_status": 0,
            "pn": 1,
            "ps": 30,
            "vmid": vmid,
            "ts": 65524344499
        }
        encoded_params = urllib.parse.urlencode(params)
        url=f"https://api.bilibili.com/x/space/bangumi/follow/list?type=1&follow_status=0&pn=1&ps=30&vmid={vmid}&ts=65524344499"
        urlList=[
            # f"https://api.bilibili.com/x/relation/stat?vmid={vmid}", #点赞数，粉丝数
            # f'https://api.bilibili.com/x/space/bangumi/follow/list?{encoded_params}', #番剧列表
            # f"https://api.bilibili.com/x/space/arc/search?mid={vmid}",
            f"https://api.bilibili.com/x/space/bangumi/follow/list?type=1&follow_status=0&pn=1&ps=30&vmid={vmid}&ts=65524344499",
            # f"https://api.bilibili.com/x/v3/fav/folder/created/list-all?up_mid={vmid}",
            # f"https://api.bilibili.com/x/space/bangumi/follow/list?type=1&follow_status=0&pn=1&ps=30&vmid={vmid}&ts=65524344499",
        ]
        Info = self.session.get(
            url,
            headers=self.headers
        )

        pattern2 = r'"series_id".*?"title":"(.*?)"'
        result2 = re.findall(pattern2, Info.text)
        result2=set(result2)
       # print(result2)
      #  print(result2)
        s=""
        for i in result2:
      #      print(i)
            s+=i+'\n'
        #print(s)
        if s=="":
            return -1
        return s

