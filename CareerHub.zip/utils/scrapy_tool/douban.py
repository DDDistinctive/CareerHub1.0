import requests
import json
import re

cookie = 'bid=-Nv_7LAbRGs; ll="118281"; __utma=30149280.1518428470.1684998816.1684998816.1684998816.1; __utmc=30149280; __utmz=30149280.1684998816.1.1.utmcsr=baidu|utmccn=(organic)|utmcmd=organic; __utmt=1; douban-fav-remind=1; ap_v=0,6.0; __utmt_douban=1; __utma=81379588.2058352095.1684998876.1684998876.1684998876.1; __utmc=81379588; __utmz=81379588.1684998876.1.1.utmcsr=douban.com|utmccn=(referral)|utmcmd=referral|utmcct=/people/159899344/; _pk_ref.100001.3ac3=%5B%22%22%2C%22%22%2C1684998876%2C%22https%3A%2F%2Fwww.douban.com%2Fpeople%2F159899344%2F%3F_i%3D4998847-Nv_7LA%22%5D; _pk_ses.100001.3ac3=*; __utmb=30149280.14.10.1684998816; __utmb=81379588.3.10.1684998876; _pk_id.100001.3ac3=c9df85c9f1510207.1684998876.1.1684998950.1684998876.'


class Douban:
    def bookinfo(self, mid):
        url = f'https://book.douban.com/people/{mid}/collect'
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36',
            'Cookie': cookie
        }
        resp = requests.get(url=url, headers=headers)
        # data_json = json.loads(resp.text)
        # print(resp.text)
        s = ""
        try:
            result = re.findall('<a.*?query.*?from:.*?>(.*?)</a>', resp.text, re.S)
            for i in result:
                i = re.sub(' ', '', i)
                i = re.sub('\n', '', i)
                i = re.sub('<img.*?>[\s\S]*?', '', i)
                i = re.sub('<span.*?>(.*?)</span>', '', i, re.S)
                i = re.sub('&#39;', '‘', i)
                i = re.sub('\n', '', i)
                if i == '':
                    continue
                if i.find('<em>') != -1:
                    continue
                if i.find('/') != -1:
                    i = i[:i.index('/')]

                s += i + '\n'
        except:
            return -1

        if s=="":
            return -1
        return s
            # print(i)
       # print(s)

    #  print(result)  # world
    def movieinfo(self, mid):
        url = f'https://movie.douban.com/people/{mid}/collect'
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36',
            'Cookie': cookie
        }
        resp = requests.get(url=url, headers=headers)
        # data_json = json.loads(resp.text)
        # print(resp.text)
        s = ""
        try:
            result = re.findall('<em>(.*?)</em>', resp.text, re.S)
            # print(result)
            for i in result:
                # i = re.sub(' ', '', i)
                # i = re.sub('\n', '', i)
                # i = re.sub('<img.*?>[\s\S]*?', '', i)
                # i = re.sub('<span.*?>(.*?)</span>', '', i, re.S)
                #
                # s += i + '\n'
                if i.find('title') != -1:
                    continue
                if i.find('/') != -1:
                    i = i[:i.index('/')]
                # print(i)
                s += i + '\n'
        except:
            return -1

        # print(s)
        if s=="":
            return -1
        return s
        # return(data_json)

#
# douban = Douban()
# print(douban.movieinfo('1486281'))
# print(douban.bookinfo('1486281'),end=' ')
