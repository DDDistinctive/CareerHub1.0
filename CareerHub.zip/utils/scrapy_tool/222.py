# import openai
# import pdfplumber
#
# from apps.contents.constants import OPENAI_KEY
#
# s="""
# Java后端工程师-万子龙.pdf
# 机组成、软件工程
# 专业技能
# 具有扎实的 Java 基础，掌握容器，并发编程和 JVM；
# 熟练掌握 MySQL 数据库，熟悉事务、索引、锁机制等，实践过常用的数据库调优方法；
# 熟悉 Redis 的数据类型及使用场景，理解持久化、事务和集群等原理；
# 熟悉常见的设计模式，例如单例模式、工厂模式和代理模式等；
# 熟悉使用 Spring、SpringMVC、SpringBoot、MyBatis 等主流开源框架，例如熟悉 Spring 框架的 IOC 和 AOP 原理；
# 熟悉计算机网络、操作系统等计算机基础知识；
# 熟悉数据结构与算法，如数组、链表、栈、队列等数据结构；
# 了解使用 Linux 常用命令，能独立部署Java后端项目；
# 了解SpringCloud，了解Nacos、Feign、GateWay等组件的作用及基本使用
# 荣誉奖项
# 1.国家大学生英语六级证书
# 2.本科期间参加大学生创新创业训练计划项目（省级）项目负责人并结题
# 3.软件著作权，SUT数学公式分析与识别实验系统
# 工作经历
# 上海硕恩网络科技股份有限公司 2022年05月 - 2022年08月
# 实习生
# 项目背景：基于各大银行的征信业务，银行向公司提供变量加工逻辑和数据字典，根据逻辑完成Java版本和SAS版本代码的编
# 写，通过Java和SAS的比对，两者一致后交付给银行。
# 工作内容：
# 参与业务变量算子代码编写
# 流程：对数据库中的表进行list化处理，一条list就是一行数据。
# 算子代码对list一行行遍历，按照对应的主键分组，对每一组表的数据进行处理计算，得出具体业务意义的变量数据。
# 不同类型的表字段之间的转换程序
# 由于一些银行使用全Varchar类型作为数据，需要将其转换为对应的Date、Integer、Double乃至BigDecimal等类型再进
# 行处理，其中涉及：表po的批量建立，mapper与xml的编写，对拿到数据后进行转换，使用到Calendar、sdf、Optional
# 流等常用方法。
# 项目经历
# 商品秒杀系统（开源项目） 2022年01月 - 2022年02月
# 技术栈：SpringBoot+Redis+Nginx+RocketMq+Sentinel+Guava+Jmeter
# 项目介绍：本系统主要针对秒杀的场景进行的开发工作，其中主要包括商品详情页和下单的功能。使用Jmeter测试接口的
# QPS。_2_TXkx_202208171543
# 功能介绍
# 使用Redis存储商品详情，由于本系统部署在分布式环境，所以采用分布式锁Redission解决缓存击穿问题；
# 使用Guava作为本地缓存，提升了系统的QPS；
# 使用集成Nginx的OpenResty，通过修改lua脚本对权重路径进行设置实现负载均衡，动静分离；将Nginx中的共享内存字
# 典区域通过设置为缓存，提高访问速度；
# 下单功能中，本来想使用数据库实现扣减库存，并且提高并发，加了索引，但是由于商品数据很多，效率依旧很低，所以采
# 用Redis进行减库存操作
# """
# print(len(s))
#
# def cv_analyze(file):
#
#     openai.api_key = OPENAI_KEY
#     all_text = ""
#
#     all_text = file
#     print(all_text)
#     # all_text=all_text[:]
#     response = openai.ChatCompletion.create(
#         model="gpt-3.5-turbo",
#         messages=[
#             {"role": "system", "content": "你将扮演专业的职业职业规划导师."},
#             {"role": "user", "content": "请基于我的简历对我进行详细的评价，你的回复尽量不要与简历内容重复，"
#                                         "请用你自己的话重新组织语言。请分段从专业技能、个人素质、经验背景、"
#                                         "文化程度、潜力发展几个方面为我的提供建议"
#                                         "再次强调你的输出需要尽可能详细并分段显示，以下是我的简历内容: \n" + all_text + "\nAI:"},
#         ]
#     )
#     # Get response from ChatGPT API
#
#     result = response['choices'][0]['message']['content']
#     print('-'*30)
#     print(result)
#     return result
# cv_analyze(s)

