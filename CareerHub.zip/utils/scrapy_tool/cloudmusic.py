import requests
import json
import urllib.parse
import urllib.parse
from lxml import etree
import re
class Cloudmusic:
    def Midinfo(self,mid):

        url = f'http://music.163.com/api/user/playlist/?offset=0&limit=100&uid={mid}'

        resp = requests.get(url=url)
        result = re.findall('"name":"(.*?)"', resp.text, re.S)
        s=""
        for i in result:
           # print(i)
            s+=i+'\n'
        if s=="":
            return -1
        return s
     #   return result
# cloudmusic=Cloudmusic()
# print(cloudmusic.Midinfo(1))

