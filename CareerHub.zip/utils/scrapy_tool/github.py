import requests
import json
class Github:
    def unameinfo(self,uname):
        url = f'https://api.github.com/users/{uname}'
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 SLBrowser/8.0.1.4031 SLBChan/11'

        }
        resp = requests.get(url=url, headers=headers)
        data_json = resp.text
        #print(data_json)
        if data_json.find('"message": "Not Found"')!=-1:
            return -1
        return(data_json)



# github=Github()
# print(github.unameinfo('AP-IA'))
# print(data_json['followers_url'])
# print(data_json['following_url'])
# resp=requests.get(url=data_json['followers_url'],headers=headers)
# print(resp.text)
# print('-'*18)
# resp=requests.get(url=str(data_json['following_url']).split('{')[0],headers=headers)
# print(github.unameinfo('AP-IA'))