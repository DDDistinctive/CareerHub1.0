import re

import requests
import json
class Jbook:
    def Midinfo(self,mid):
        url = f'https://www.jianshu.com/u/{mid}'
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36'
        }
        resp = requests.get(url=url, headers=headers)
        # 定义正则表达式模式
        pattern = r'<a class="title" target="_blank" href="[^"]*">([^<]*)</a>'

        # 使用re.findall提取匹配的内容
        matches = re.findall(pattern, resp.text)

        # 输出匹配的内容
        result=''
        for match in matches:
            result+=match+'\n'
        return result
# jianshu=Jbook();
# 
# print(jianshu.Midinfo('b3b2c03354f3'))
