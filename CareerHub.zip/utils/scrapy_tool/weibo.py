import re

import requests
import json
class Weibo:
    def Midinfo(self,mid):
        url = f'https://weibo.com/ajax/statuses/mymblog?uid={mid}&page=1&feature=0'
        headers = {

            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Cookie':'XSRF-TOKEN=UfU87K2l-pUpP_gzPIp5nJoy; _s_tentry=weibo.com; '
                     'Apache=339110033316.9317.1684850147588; SINAGLOBAL=339110033316.9317.1684850147588; '
                     'ULV=1684850147678:1:1:1:339110033316.9317.1684850147588:; SSOLoginState=1684850291; '
                     'SCF=AssJrS8nI_bEv7RmZ4djF_4ZhzRVcrEN8O7i7Hj8N879EJPcP7LU_3d6bOHeTiG8a2a30ZHm2edqpHrK3BEeIvI.; '
                     'PC_TOKEN=7d44fec34d; '
                     'SUB=_2AkMSFBlGf8NxqwFRmfkXzW7laYx1wwjEieKkSOidJRMxHRl'
                     '-yT9vqm4QtRB6OZQ3qmmqXl17d8fgxBZprdiKpsc0DQB2; '
                     'SUBP=0033WrSXqPxfM72-Ws9jqgMF55529P9D9W56EITv6zUWDbcTUTFyjsjh; '
                     'login_sid_t=5925283cf571b804bb6af1b32ad7d316; cross_origin_proto=SSL; '
                     'WBStorage=4d96c54e|undefined; UOR=,,login.sina.com.cn; wb_view_log=1182*6651.625; '
                     'WBtopGlobal_register_version=2023110615; '
                     'WBPSESS=HOKMwFaOhMG7Cl30d6Y-8ahJ8mbUeUeIV7_8NQlF8orVvOKZLrgG4UAsWh8BnkxEuMzoT'
                     '-3lIYV_rs3uWyjxL2BDoSSghx-Wg6RIeO_VebjjyulNXylBsOw4QS0nfrlKjNPZjMgt2ptur4JKOMKcDDboJ2yRgVnjzeXggzY6d6s= '
        }

        resp = requests.get(url=url, headers=headers)
        pattern = r'"text_raw":"([^"]*)","text"'
       # print(resp.text)
        # 使用re.search提取匹配的内容
        matches = re.findall(pattern, resp.text)
        result=''
        # 输出匹配的内容
        for match in matches:
            # extracted_text = match.group(1)
           # print(match)
            result+=match+'\n'
     #   print(resp.text)
     #    print(result)
        return result[:200]
# weibo =Weibo();
# print(weibo.Midinfo(7166486922))

