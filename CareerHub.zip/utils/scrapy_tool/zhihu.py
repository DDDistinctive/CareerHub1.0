import requests
import json
import urllib.parse
class Zhihu:
    def Midinfo(self,uname):
        url = f'https://www.zhihu.com/api/v5.1/topics/{uname}/following_topics_contributions'

        headers = {

            'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36',
            'cookie': '_zap=391c0b8b-f635-4941-9511-abb4452a39da; d_c0="APCRm9g1MRWPTvxnMTIpRlZ1hKxt6WXzung=|1656859702"; _9755xjdesxxd_=32; YD00517437729195%3AWM_TID=Cmb3X2phHs9EAVEEUFaBBuw%2B7SNs3MdY; __snaker__id=hD9N7Uaf6lGsw7Rx; q_c1=5b11d7d2ee66468fb633647ffcdd089d|1665313195000|1665313195000; _xsrf=I9yBvAWqylRE6rIIUNoaumrUVhJrEllB; tst=r; captcha_ticket_v2=2|1:0|10:1684850778|17:captcha_ticket_v2|704:eyJ2YWxpZGF0ZSI6IkNOMzFfaGQyNFkybE1tWGVkMG9IMlhFdmZRNV9rREp2ZEs1UXZQVmVKTE83TkVTcjdPeURaU0lmdUV0NUdWMEtXbThNUnpIQXcwcGY2Q1R3TjI3b1EwY1NOejh4MEI4MktGaU0xWlpVRmdBYm9UandOQjc4Nlo4N3dLeFUyeVNmTGExSFFYVFd6RFBaVEhvRlJ0X3pfMVA4TUg5VkJ5YVkwSlZ5d0ZZT3BZbmZabzBFVXpROFNvNzBhcDJqN183cC5iS09OQmljVWlseWxSSy1vYmFkQnAuODdVV0NSUHZaQ0NiQjZCZ3dCeVR6TzJidWtKSzlFcHRjWjBhUWZWSTVDNjlkNlNPOHVQZEdjQ1BPa2ROVmtJMXpPNFkyU0VWSVA2NEVlVmVkbUQud2xLdy5WcF83WS5ublkycXEuSnRzdzVXVGpxcmFFY3haYzFLclYtVnBJUVVCZU1hV3h4dU9CcnYtaVh2ZDljVDVQQTZjbUZXZmRjZDlILXlRVThXNXVzemFtSW1XRDhPOWJHTTZlVTJYNUQtQmlGZTRfVzJTRDhoY1VTTXlwYUxLSW1nN0huaWFNemJKYXQ4U1dKVm1UWmFLUE93R1JucmZZWVdYbmdZUDItSDZYTkY5Ml9aYkt4am1kOWg3cTIxTG1Xd3NRbjVjSDlZUWJ0ci51Z3dwMyJ9|67f1e69cd84b4228f48873506e55900fdafceae718cf107d4fe6f0610cc2e192; Hm_lvt_98beee57fd2ef70ccdd5ca52b9740c49=1684811073,1685092009,1685105173,1685673510; SESSIONID=HjVI2IOV1ptGHxE3uqtsnMYD3hvLywIoNRixyxNc4tQ; JOID=W1oUBUpHDt2Njkk_UUjNBWuNSwZMBGeMw7QLcwB-darNwTlxYWhcpOaNQTtRNkRSdOJZR0_4k4WqW36bHfBFiwE=; osd=Wl0UBktGCd2Oj0g4UUvMBGyNSAdNA2ePwrUMcwN_dK3NwjhwZmhfpeeKQThQN0NSd-NYQE_7koStW32aHPdFiAA=; gdxidpyhxdE=En9uTsRikp43enDWesxZ7idJPu9QLfbW3ijIVcgz8sB%5Co%2F6atgu0qJTTHaWMKAeeUSwM%2BPSrOqy%2B8D5sypK8bRN%5CwltfWGvLmlcEKxpsPlagkEmT2YBQE2nhrm9f9k38Y61jwsDppebs%2B%2BdW5be1jzwyiZxp5IXXXjoDupuxyN4vnZmb%3A1685674414282; YD00517437729195%3AWM_NI=jtofftK7j1DZHqw43RgK7jCdNuNimcjIq%2FiDISJAeC8It9UQjavzNnCMhHRe09MgfK4LGaBO7TjqqNZI45PF%2BW182N6KX3HEua4looM5balyyGORcqaKk7D%2Ff3P3YumSTE4%3D; YD00517437729195%3AWM_NIKE=9ca17ae2e6ffcda170e2e6ee84e760afa982a8fc528bac8eb6d15e839e9b87d53b91aa9c96bb609b8abdb3b62af0fea7c3b92aaaaca187e58089e9a6d2c7528cafb9d5b25aa595f98bc2708eab828af069aa97bfd0ec508b8d86a2e849fc97bcdad85baabfba9bcd668193a8a9d16ff4e78388e541f8948982c145f58ca692f4469a97fcd6d34ee989ffd9b146f69598d4cb4fb7bffc8dee658febae82ef73bb9981b3e27ba395a5d8c725a6eda0d4dc7faf8d9ca6b737e2a3; Hm_lpvt_98beee57fd2ef70ccdd5ca52b9740c49=1685674010; captcha_session_v2=2|1:0|10:1685674011|18:captcha_session_v2|88:cjMyeVNvNlBxN3FZQzdWcFU3QXUwTVNNd1d1R0Z0UFhqcU41bHp0ZXBtVERnNWdmaHIxb2t2ZC9rWnlhdEw2Yw==|7e41983f8b98b5a53b144a95c9ad5d6866a0a81be554126557f407c550f8729e; KLBRSID=0a401b23e8a71b70de2f4b37f5b4e379|1685674018|1685673508',

            'X-Zse-93':'101_3_3.0',
            'x-zse-96': '2.0_+LynnJlkCY=UcKogWCIPH5bGDJ1KJnpdMYhGfJKjnwB=CF1+IjZtj635piHk3Au6',
            'x-zst-81': '3_2.0aR_sn77yn6O92wOB8hPZnQr0EMYxc4f18wNBUgpTQ6nxERFZBXY0-4Lm-h3_tufIwJS8gcxTgJS_AuPZNcXCTwxI78YxEM20s4PGDwN8gGcYAupMWufIeQuK7AFpS6O1vukyQ_R0rRnsyukMGvxBEqeCiRnxEL2ZZrxmDucmqhPXnXFMTAoTF6RhRuLPFHL8PGOqnvumXcNL_9oLZhx03uVOaGcpTqtYYw3YJhumuUY9_GFGmh2CIgcTveeMuhe_YQN80uL8QTp_eug9H9Y91Dwq6iXK19tmm7V12iVG3wcuLGcGGRVBTUX9-9O1TDLBYRYBgU39cuVmocNKXCLZtJ9BC9OOc_cfBCO8QDr_8utmCqfz5vS_0vXGW9x9XggKc9eMwbCycTX11BF04hLOJRNCjrx_SB3MK4eLLCXYkCwf0qLGfgN9zwxBr8wxiCHMfhYK2rc0x92VOqxC7cXqBqe8NBNLwwXBwBgC'
        }
        params={
            "include": "data[*].topic.introduction",
            "offset": 0,
            "limit": 20
        }
        url=url+'?'+urllib.parse.urlencode(params)
        url=url.replace('%2A','*')

        '''
        https://www.zhihu.com/api/v5.1/topics/he-he-123-46/following_topics_contributions?include=data%5B*%5D.topic.introduction&offset=0&limit=20
        '''
        resp = requests.get(url=url, headers=headers)

        # print(resp.text)
        json_data=json.loads(resp.text)
        # data[0].topic.name
        try:
            info_list=json_data['data']
        except:
            return -1
        result=""
        for i in info_list:
           # print(1)
            result+=(i['topic']['name'])+'\n'
           # print(result)
        return result
# zhihu=Zhihu()
# print(zhihu.Midinfo('he-he-123-46'))
# #

