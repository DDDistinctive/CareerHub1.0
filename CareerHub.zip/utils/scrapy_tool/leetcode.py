import requests
import json
import urllib.parse
class Leetcode:
    def find_data(self,userSlug: str):
        url = 'https://leetcode.cn/graphql/'
        headers = {
            'Referer': 'https://leetcode.cn/u/za-mao-xiao-ji-4/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.42'
        }
        data = {
            "query": "\n    query userProfilePublicProfile($userSlug: String!) {\n  userProfilePublicProfile(userSlug: $userSlug) {\n    haveFollowed\n    siteRanking\n    profile {\n      userSlug\n      realName\n      aboutMe\n      asciiCode\n      userAvatar\n      gender\n      websites\n      skillTags\n      ipRegion\n      birthday\n      location\n      useDefaultAvatar\n      github\n      school: schoolV2 {\n        schoolId\n        logo\n        name\n      }\n      company: companyV2 {\n        id\n        logo\n        name\n      }\n      job\n      globalLocation {\n        country\n        province\n        city\n        overseasCity\n      }\n      socialAccounts {\n        provider\n        profileUrl\n      }\n      skillSet {\n        langLevels {\n          langName\n          langVerboseName\n          level\n        }\n        topics {\n          slug\n          name\n          translatedName\n        }\n        topicAreaScores {\n          score\n          topicArea {\n            name\n            slug\n          }\n        }\n      }\n    }\n    educationRecordList {\n      unverifiedOrganizationName\n    }\n    occupationRecordList {\n      unverifiedOrganizationName\n      jobTitle\n    }\n  }\n}\n    ",

            "variables": {
                "userSlug": f"{userSlug}"
            },

            "operationName": "userProfilePublicProfile"}

        resp = requests.post(url=url, json=data, headers=headers)
        #  data.userProfilePublicProfile.profile.skillSet data.userProfilePublicProfile.profile.skillSet.langLevels
        json_data = json.loads(resp.text)
        try:
            info_list = json_data['data']['userProfilePublicProfile']['profile']['skillSet']
        except:
            return -1
    #    print(info_list['langLevels'], '\n\n', info_list['topics'], info_list['topicAreaScores'])
        return info_list['langLevels'], info_list['topics'], info_list['topicAreaScores']

    def searchUser(self,name):
        if name==-1:
            return -1
        url = 'https://leetcode.cn/graphql/noj-go/'
        data = {
            "query": "\n    query users($data: UsersInput!) {\n  users(in: $data) {\n    hasMore\n    nodes {\n      avatar\n      siteRanking\n      userSlug\n      realName\n      aboutMe\n      reputationLevel\n      followedByMe\n      followerNumber\n      followingNumber\n    }\n  }\n}\n    ",
            "variables": {"data": {"keyWords": f"{name}", "limit": 12, "offset": 0}},
            "operationName": "users"
            }
        headers = {
            # '',

            'Host': 'leetcode.cn',
            'Cookie': 'Hm_lvt_f0faad39bcf8471e3ab3ef70125152c3=1684768747; csrftoken=YinKXir9uhrwYDljsCbjfE9vQf8SatRwhGd8Gmib9lEqTZypxOFTAtgRqkGmVugi; gr_user_id=3046b80b-c56e-4fd5-8a58-1cb4511bf757; _gid=GA1.2.1347561070.1684768747; _bl_uid=OFlvzhvayqmz4Xtwd9Rpc15yXL84; Hm_lvt_fa218a3ff7179639febdb15e372f411c=1684768785; Hm_lpvt_fa218a3ff7179639febdb15e372f411c=1684768785; _ga_PDVPZYN3CW=GS1.1.1684768747.1.1.1684768791.0.0.0; _ga=GA1.2.1187378087.1684768747; a2873925c34ecbd2_gr_session_id=ed286926-5cca-4556-b3e8-8ce9db6e9d4e; a2873925c34ecbd2_gr_session_id_sent_vst=ed286926-5cca-4556-b3e8-8ce9db6e9d4e; Hm_lpvt_f0faad39bcf8471e3ab3ef70125152c3=1684771078',
            'Referer': 'https://leetcode.cn/search/?q=%E6%9D%82%E6%AF%9B%E5%B0%8F%E9%B8%A1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 SLBrowser/8.0.1.4031 SLBChan/11',
        }

        resp = requests.post(url=url, json=data, headers=headers)

        json_data = json.loads(resp.text)
        userList = json_data['data']['users']['nodes']
        for i in userList:
            print('userSlug:', i['userSlug'], 'realName:', i['realName'], 'avatar:', i['avatar'])

# lc=Leetcode();
# # lc.searchUser('杂毛小鸡')
# print(lc.find_data('za-mao-xiao-ji-411'))

