function validateEmail(email) {
    // 使用正则表达式进行邮箱格式验证
    var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

$(document).ready(function () {
    var error_email = false
    var error_password = false
    var error_email_code = false
    $("#email").blur(function () {
        // 在此处编写失去焦点时要执行的代码
        var email = $(this).val();
        error_email = !validateEmail(email);
        var error_ele = $('#error_email')
        if (error_email === true) {
            error_ele.text("请填写正确的邮箱")
            error_ele.show();
        } else {
            error_ele.hide();
        }
    });
    $("#newPassword").blur(function () {
        // 在此处编写失去焦点时要执行的代码
        var password = $(this).val();
        var re = /^[a-zA-z0-9_-]{5,20}$/
        error_password = !re.test(password);
        var error_ele = $('#error_password')
        if (error_password === true) {
            error_ele.text('请填写正确的密码')
            error_ele.show()
        } else {
            error_ele.hide()
        }
    });
    $("#verificationCode").blur(function () {
        // 在此处编写失去焦点时要执行的代码
    });
    $("#send_email_code").click(function () {
        var err_sendemail_ele = $('#error_send_email')
        err_sendemail_ele.hide()
        var email = $('#email').val();
        error_email = !validateEmail(email);
        var error_ele = $('#error_email')
        if (error_email === true) {
            error_ele.text("请填写正确的邮箱")
            error_ele.show();
            return;
        } else {
            error_ele.hide();
        }

        let url = '/email_codes/' + email + '/';

        axios.get(url, {
            responseType: 'json'
        })
            .then(response => {
                if (response.data.code === '0') {
                    // 展示倒计时60秒
                    let num = 60;

                    // setInterval('回调函数', '时间间隔(毫秒)')
                    let t = setInterval(() => {
                        if (num === 1) {
                            // 停止回调函数
                            clearInterval(t);
                            $(this).text('获取邮箱验证码')
                            this.send_flag = false;

                        } else {
                            num -= 1;
                            $(this).text(num + '秒')
                        }

                    }, 1000)
                } else {
                    err_sendemail_ele.text('访问过于频繁')
                    err_sendemail_ele.show()
                }

            })
            .catch(error => {
                console.log(error.response);

            })
    });

});