    // const username = document.querySelector('[name=username]')
    // username.addEventListener('change', verifyName)
    // function verifyName() {
    //   const span = username.nextElementSibling
    //   const reg = /^[a-zA-Z0-9-_]{6,10}$/
    //   if (!reg.test(username.value)) {
    //     span.innerText = '用户名输入错误'
    //     return false
    //   }
    //   span.innerText = ''
    //   return true
    // }
    //
    // const password = document.querySelector('[name=password]')
    // password.addEventListener('change', verifyPwd)
    // function verifyPwd() {
    //   const span = password.nextElementSibling
    //   const reg = /^[a-zA-Z0-9-_]{6,20}$/
    //   if (!reg.test(password.value)) {
    //     span.innerText = '密码格式错误'
    //     return false
    //   }
    //   span.innerText = ''
    //   return true
    // }
    //
    // const email = document.querySelector('[name=email]');
    // email.addEventListener('change',verifyEmail)
    // function verifyEmail() {
    //    const span = email.nextElementSibling
    //     const  reg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(.[a-zA-Z0-9_-]+)+$/
    //     if(!reg.test(email.value)){
    //         span.innerHTML = '邮箱格式错误'
    //          return false
    //   }
    //   span.innerText = ''
    //   return true
    // }
    //
    //
    //
    // (function () {
    //   const code = document.querySelector('#get_email_code')
    //   let flag = true  //节流阀
    //   code.addEventListener('click', function () {
    //
    //     if (flag) {
    //         axios.get()
    //       flag = false
    //       let i = 60
    //       code.innerHTML = `0${i}秒后重新获取`
    //       let timerId = setInterval(function () {
    //         i--
    //         code.innerHTML = `0${i}秒后重新获取`
    //         if (i === 0) {
    //           clearInterval(timerId)
    //           code.innerHTML = `重新获取`
    //           flag = true
    //         }
    //       }, 1000)
    //     }
    //   })
    // })();
    //
    // const form = document.querySelector('form')
    // form.addEventListener('submit', function (e) {
    //     if (!verifyName()) e.preventDefault()
    //     if (!verifyPwd()) e.preventDefault()
    //     if (!verifyEmail()) e.preventDefault()
    //
    // })




    function is_show_errmsg(state, error_show, errmsg) {

    if (state === true) {
        error_show.text(errmsg)
        error_show.show()
    } else {
        error_show.hide()
    }
}
// 提取地址栏中的查询字符串
function get_query_string(name) {
    let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
    let r = window.location.search.substr(1).match(reg);
    if (r != null) {
        return decodeURI(r[2]);
    }
    return null;
}
$(document).ready(function () {

    $('#username').blur(function () {
        var re = /^[0-9A-Za-z]{5,20}$/
        var username = $(this).val()
        var state = !re.test(username)
        var error_ele = $('#error_username')
        is_show_errmsg(state, error_ele, '账号错误')
        if (state === true) {
            return
        }
        let url = '/users/usernames/' + username + '/count/';
        axios.get(url, {
            responseType: 'json'
        })
            // 请求成功  function(response){}
            .then(response => {

                if (response.data.count === 1) {
                    // 用户名已经存在
                    error_ele.text('用户名已经存在')
                    error_ele.show()

                } else {
                    or_ele.hide()
                }
            })
            // 请求不成功
            .catch(error => {
                console.log(error.response)
            })

    });
    $('#password').blur(function () {
        var re = /^[0-9A-Za-z]{8,20}$/
        var password = $(this).val()
        is_show_errmsg(!re.test(password), $('#error_password'), '密码格式错误')

    });
    $('#email').blur(function () {
        var email = $(this).val()
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        is_show_errmsg(!re.test(email), $('#error_email'), '邮箱格式错误')
    });

    $('#email_code').blur(function () {
        //验证码格式验证
    });
    $('#error_email_code').hide();


    $('#get_email_code').click(function () {
        var email = $('#email').val()
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        var state = !re.test(email)
        if (state === true) {
            is_show_errmsg(state, $('#error_email'), '请填写正确的邮箱')
            return;
        }
        let url = '/email_codes/' + email + '/';
        var error_send = $('#error_email_code')
        axios.get(url, {
            responseType: 'json'
        })
            .then(response => {
                if (response.data.code === '0') {
                    // 展示倒计时60秒
                    let num = 60;
                    // setInterval('回调函数', '时间间隔(毫秒)')
                    let t = setInterval(() => {
                        if (num === 1) {
                            // 停止回调函数
                            clearInterval(t);
                            $(this).text('获取验证码')
                        } else {
                            num -= 1;
                            $(this).text(num + '秒');
                        }

                    }, 1000)
                    error_send.hide()
                } else {
                    error_send.text('访问过于频繁')
                    error_send.show()
                }

            })
            .catch(error => {
                console.log(error.response);
            })

    });


    $('#qq_login').click(function (){
        let next=get_query_string('next')||'/';
        let url='/qq/login/?next='+next;
        axios.get(url,{
            responseType:'json'
            }
        )
            .then(response=>{
                location.href=response.data.login_url;
            })
            .catch(error=>{
                console.log(error.response)
            })

    })

})
