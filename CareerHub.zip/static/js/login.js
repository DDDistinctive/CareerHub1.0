//     const username = document.querySelector('[name=username]')
//     username.addEventListener('change', verifyName)
//    /* function verifyName() {
//       const span = username.nextElementSibling
//       const reg = /^[a-zA-Z0-9-_]{6,10}$/
//       if (!reg.test(username.value)) {
//         span.innerText = '用户名输入错误'
//         return false
//       }
//       span.innerText = ''
//       return true
//     }
// */
// function verifyName() {
//   const span = username.nextElementSibling
//   const value = username.value.trim()
//   const emailReg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
//   const nameReg = /^[a-zA-Z0-9-_]{5,20}$/
//
//   if (emailReg.test(value)) {
//     span.innerText = ''
//     return true
//   } else if (nameReg.test(value)) {
//     span.innerText = ''
//     return true
//   } else {
//     span.innerText = '请输入正确的用户名或邮箱'
//     return false
//   }
// }//添加用户名验证逻辑
//
//
//     const password = document.querySelector('[name=password]')
//     password.addEventListener('change', verifyPwd)
//     function verifyPwd() {
//       const span = password.nextElementSibling
//       const reg = /^[a-zA-Z0-9-_]{6,20}$/
//       if (!reg.test(password.value)) {
//         span.innerText = '密码格式错误'
//         return false
//       }
//       span.innerText = ''
//       return true
//     }
//
//
//     // const code = document.querySelector('[name=photo_code]')
//     // code.addEventListener('change', verifyCode)
//     // function verifyCode() {
//     //   const span = code.nextElementSibling
//     //   const reg = /^\d{4}$/
//     //   if (!reg.test(code.value)) {
//     //     span.innerText = '图形验证码错误'
//     //     return false
//     //   }
//     //   span.innerText = ''
//     //   return true
//     // }
//
//
// // generate_image_code(){
// // // uuid 发生变化
// // this.uuid = generateUUID();
// // this.image_code_url = '/image_codes/'+ this.uuid +'/'
// // }
//
// //
//
//     function generateImageCode(imgElement) {
//         const imageCodeUUID = generateUUID();
//         const imageCodeURL = "http://127.0.0.1:8000/image_codes/" + imageCodeUUID + "/";
//         imgElement.src = imageCodeURL;
//         const errorMessageElement = document.getElementById("error_message");
//         errorMessageElement.innerHTML = "图形验证码错误";
//     }
//
//     function generateUUID() {
//         return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
//             const r = Math.random() * 16 | 0,
//                 v = c == 'x' ? r : (r & 0x3 | 0x8);
//             return v.toString(16);
//         });
//     }
//
//
//
//       document.querySelector('form').addEventListener('submit', function(event) {
//           const codeInput = document.getElementById('code');
//           const codeValue = codeInput.value;
//
//
//           const codeRegex = /^[a-zA-Z0-9]{4}$/;
//           if (!codeRegex.test(codeValue)) {
//             event.preventDefault();
//               const errorMessageElement = document.getElementById("error_message");
//               errorMessageElement.innerHTML = "验证码格式不正确";
//         }
//     });
//
//
//
//
//     const form = document.querySelector('form')
//     form.addEventListener('submit', function (e) {
//         if (!verifyName()) e.preventDefault()
//         if (!verifyPwd()) e.preventDefault()
//     })
//


















function valiaccount(account) {
    var re_email = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    var re_uname = /^[0-9A-Za-z]{5,20}$/
    return re_email.test(account) || re_uname.test(account)
}
// 提取地址栏中的查询字符串
function get_query_string(name) {
    let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
    let r = window.location.search.substr(1).match(reg);
    if (r != null) {
        return decodeURI(r[2]);
    }
    return null;
}
$(document).ready(function () {
    $('#username').blur(function () {
            var username = $(this).val()
            var error_username = !valiaccount(username)
            var error_show = $('#error_username')
            if (error_username === true) {
                error_show.text('账号错误')
                error_show.show()
            } else {
                error_show.hide()
            }
        }
    );
    $('#password').blur(function () {
            var password = $(this).val()
            var re = /^[0-9A-Za-z]{8,20}$/
            var error_username = !re.test(password)
            var error_show = $('#error_password')
            if (error_username === true) {
                error_show.text('密码格式错误')
                error_show.show()
            } else {
                error_show.hide()
            }
        }
    )

})

